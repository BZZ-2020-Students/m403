Tested on..: Java 15
Requirement: Java 13
Reason.....: advanced switch-case